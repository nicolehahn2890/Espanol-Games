# Handoff: Tema «Joya» — modo Candy Crush oscuro para Juegos de Español

## Overview
Este paquete reviste la app **Juegos de Español** (`nicolehahn2890/Espanol-Games`)
con un look **Candy Crush oscuro** llamado **«Joya»**: un tablero de lila profundo,
fichas y botones tipo joya con halo de luz, paneles de **vidrio esmerilado**
(frosted glass) y un logotipo de gema dorada con resplandor. Mantiene intacta la
paleta de caramelo (verde/azul/morado/naranja/amarillo/rojo) y toda la mecánica —
solo cambia la **piel** visual.

Es un **re-skin puramente de CSS**. No cambia el HTML, los componentes React ni la
lógica: reaprovecha exactamente las clases que la app ya usa (`.panel`, `.btn-green`,
`.game-tile`, `.wordle-cell`, `.home-title .brand`, etc.).

## About the Design Files
Los archivos de este bundle son **referencias de diseño**:
- `joya.css` — **la implementación lista para producción** (CSS real, clases reales
  de la app). Es lo que hay que integrar.
- `Candy-Crush-Redesign.html` + `themes.css` — el **prototipo HTML** donde se exploró
  la dirección (incluye también la variante «Caramelo» descartada, bajo `.theme-caramelo`,
  que puedes ignorar). Sirve como referencia visual; **no** se copia al repo.

La tarea es aplicar `joya.css` en el repo real (React + TypeScript + Vite), siguiendo
sus convenciones. Como es CSS sobre clases ya existentes, la integración es directa.

## Fidelity
**Alta fidelidad (hi-fi).** Colores, gradientes, sombras y blur son finales. El
`joya.css` adjunto reproduce el resultado tal cual; intégralo sin reinterpretar.

---

## Cómo aplicarlo (paso a paso para Claude Code)

> Repo objetivo: `nicolehahn2890/Espanol-Games`. Estilos en `src/styles/`,
> importados desde `src/main.tsx`.

### Opción A — rápida y reversible (recomendada para probar)
1. Copia `joya.css` a **`src/styles/joya.css`**.
2. En **`src/main.tsx`**, impórtalo **el último**, después de los demás estilos:
   ```ts
   import './styles/tokens.css';
   import './styles/base.css';
   import './styles/animations.css';
   import './styles/components.css';
   import './styles/glossy.css';
   import './styles/joya.css';   // 👈 añadir al final
   ```
   (El orden real puede variar; lo único importante es que `joya.css` vaya
   **después** de `tokens.css`, `base.css`, `components.css` y `glossy.css`.)
3. Listo. Para volver al tema claro, comenta esa única línea.

### Opción B — integración «de verdad» (sin archivo extra)
Si prefieres no añadir un stylesheet que pisa a los demás:
1. **`src/styles/tokens.css`** → sustituye en `:root` los valores de superficie y
   texto por los del bloque «Tokens en modo oscuro joya» de `joya.css`
   (`--bg`, `--bg-soft`, `--card`, `--border`, `--border-strong`, `--text`,
   `--text-dim`, `--text-faint`). **No** cambies los colores de caramelo
   (`--green`, `--blue`, …): se conservan.
2. **`src/styles/base.css`** → reemplaza el `background:` del selector `body` por el
   del bloque «Tablero Candy Crush» de `joya.css`.
3. **`src/styles/glossy.css`** → pega el resto de reglas de `joya.css` (paneles,
   botones, fichas, celdas, explicación, resultados, toast) al final. Puedes quitar
   los `!important` si las colocas después de las reglas que pisan.

Ambas opciones dan el mismo resultado visual.

---

## Screens / Views (cómo se ve cada pantalla con el tema)
El tema afecta a todas las pantallas existentes; no añade ninguna nueva.

- **Inicio (Home).** Fondo lila con focos de luz. Logo «Juegos de Español» como gema
  dorada→rosa con resplandor (sin contorno blanco). Panel de nivel/racha en vidrio
  esmerilado. Las 4 fichas de juego mantienen su color pero ganan halo exterior.
- **Quiz.** Tarjeta de reto en vidrio; opciones en reposo en vidrio lila; la opción
  correcta sigue en verde y la fallada en rojo (sin cambios, ya contrastan). Hueco
  de la frase en cian (`#7fdcff`).
- **La Palabra (Wordle).** Celdas vacías y teclado en vidrio; `exact`/`present`
  conservan verde/amarillo; `absent` pasa a un lila apagado (`#3a2d57`).
- **Parejas / Grupos.** Tarjetas en vidrio; seleccionado en azul/lila-tinta; grupos
  resueltos conservan sus colores (`sg-0..3`).
- **Estadísticas / Logros / Ajustes.** Paneles, métricas y filas en vidrio; barras
  sobre canal oscuro; títulos de sección en texto claro.

## Interactions & Behavior
Sin cambios. Se conservan los gestos «3D» (los elementos se hunden al pulsar), las
entradas con muelle de Framer Motion, el confeti y el flip de celdas. `joya.css` solo
redefine color/relleno/sombra; las transiciones y animaciones existentes siguen igual.
Respeta `prefers-reduced-motion` como ya hace la app.

## State Management
Ninguno. Es un cambio puramente visual.

---

## Design Tokens (valores exactos del tema Joya)

**Superficies y texto (reemplazan a los claros):**
| Token | Valor |
|---|---|
| `--bg` | `#1d0a3e` |
| `--bg-soft` | `rgba(255,255,255,0.09)` |
| `--card` | `rgba(70,38,120,0.55)` |
| `--border` | `rgba(255,255,255,0.16)` |
| `--border-strong` | `rgba(255,255,255,0.24)` |
| `--text` | `#f4eeff` |
| `--text-dim` | `#c7b6ee` |
| `--text-faint` | `#9b86cc` |
| `--text-on-color` | `#ffffff` |

**Paleta de caramelo (SIN cambios):** `--green #58cc02`, `--blue #1cb0f6`,
`--purple #a560f8`, `--orange #ff9600`, `--red #ff4b4b`, `--yellow #ffc800`
(+ sus variantes `-dark` / `-soft`).

**Fondo del tablero (body):** capa base `linear-gradient(176deg,#3a1a70,#29104f 48%,#1d0a3e)`
con 5 `radial-gradient` de focos de joya (lila `#aa5cff`, azul, rosa, verde, amarillo)
en baja opacidad. `background-attachment: fixed`.

**Vidrio de panel:** `linear-gradient(180deg, rgba(96,52,156,.62), rgba(58,28,104,.58))`,
borde `rgba(255,255,255,.18)`, `backdrop-filter: blur(10px)`, sombra
`0 12px 34px rgba(16,4,40,.55)` + brillo interior.

**Halo de fichas/botones:** sombra de color al ~45–55 % de opacidad del propio color
del elemento (ver `--tile-glow` y los `box-shadow` de `.btn-*`).

**Logo (`.home-title .brand`):** gradiente `#fff3a8 → #ffd24a (42%) → #ff8ad0`, clip a
texto, **sin** `-webkit-text-stroke`, `drop-shadow` de resplandor rosa + sombra oscura.

> Tipografías: sin cambios (Fredoka display + Plus Jakarta Sans UI).

## Assets
Ninguno nuevo. El icono de app E·S·P·A y los iconos SVG propios se mantienen.

## Files
- `joya.css` — **archivo a integrar** (CSS de producción, clases reales del repo).
- `Candy-Crush-Redesign.html` — prototipo de referencia visual (las dos direcciones
  exploradas; «Joya» es la elegida).
- `themes.css` — CSS del prototipo (versión *scoped* bajo `.theme-joya` / `.theme-caramelo`);
  solo referencia, no se integra.

> Nota: el prototipo HTML usa el design system de exploración, así que abierto suelto
> puede no renderizar idéntico; la fuente de verdad para integrar es **`joya.css`**.
